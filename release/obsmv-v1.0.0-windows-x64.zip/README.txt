============================================================
OBSMV - OBS Stream Music Visualizer (v1.0.0)
Native OBS Studio Plugin (C++20 / libobs GPU rendering)
============================================================

Official Release: https://github.com/StreamMusicViewer/OBSMV

--- QUICK INSTALLATION (WINDOWS) ---

Method 1 (Automatic):
  1. Extract this entire zip archive to a folder.
  2. Make sure OBS Studio is closed.
  3. Double-click "install.bat" (it will automatically ask for admin rights).
  4. Launch OBS Studio!

Method 2 (Manual):
  1. Copy "obs-plugins\64bit\obsmv.dll" to:
     C:\Program Files\obs-studio\obs-plugins\64bit\
  2. Copy "data\obs-plugins\obsmv" to:
     C:\Program Files\obs-studio\data\obs-plugins\obsmv\
  3. Launch OBS Studio!

--- FEATURES ---
- 100% Native GPU rendering (Direct3D 11 / OpenGL via libobs gs_* API)
- Zero Browser Source / zero CEF overhead (ultra-low CPU/RAM usage)
- Real-Time Audio Visualizer (Bars, Mirrored, Spline Wave, Circular)
- Catmull-Rom cubic spline interpolation for ultra-smooth fluid curves
- Dynamic 2-Color Palette: extracts vibrant accent + dominant primary base from album art
- Adaptive Dark / Light frosted glass themes with high-contrast typography
- Native Windows Font Selector: pick any font installed on your PC
- Multi-Source Integration:
    * "OBSMV (Visualizer + Now Playing)" - All-in-one combined source
    * "OBSMV Visualizer" - Dedicated audio visualizer
    * "OBSMV Now Playing" - Dedicated music card
- Seamless hybrid media detection (Windows SMTC native + OSMV daemon sync)

--- LICENSE ---
GNU General Public License v3.0 (GPL-3.0)
Developed by Ulyxx3 for the StreamMusicViewer organization.
